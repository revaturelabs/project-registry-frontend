export class Role {
    id:number;
    type: string;
    
    constructor(id:number, type:string){
        this.id = id;
        this.type = type;
    }
}